using System.Reflection;
using System.Runtime.InteropServices;

[assembly: AssemblyTitle("NRules.Samples.MissManners.Rules")]
[assembly: AssemblyDescription("")]
[assembly: ComVisible(false)]
