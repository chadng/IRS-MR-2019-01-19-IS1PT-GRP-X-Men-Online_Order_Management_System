using System;
using NRules.Fluent.Dsl;
using NRules.Samples.SimpleRules.Domain;

namespace NRules.Samples.SimpleRules.Rules
{
    public class TestRule : Rule
    {
        public override void Define()
        {
            Customer customer = null;
            Account account = null;

             


            When()
                .Match<Customer>(() => customer, c => c.Target == "test");

            Then()
                .Do(ctx =>
                    Console.WriteLine("Target----"));


        }
    }
}