﻿namespace NRules.Samples.SimpleRules.Domain
{
    public class Customer
    {
        public string Name { get;  set; }
        public bool IsPreferred { get; set; }
        public string Target { get; set; }
        public Customer(string name)
        {
            Name = name;
        }

        public void setTarget(string Target) {
            this.Target = Target;
        }
    }
}