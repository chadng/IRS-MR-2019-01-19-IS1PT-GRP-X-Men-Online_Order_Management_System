using System.Reflection;
using System.Runtime.InteropServices;

[assembly: AssemblyTitle("NRules.Samples.SimpleRules")]
[assembly: AssemblyDescription("")]
[assembly: ComVisible(false)]
