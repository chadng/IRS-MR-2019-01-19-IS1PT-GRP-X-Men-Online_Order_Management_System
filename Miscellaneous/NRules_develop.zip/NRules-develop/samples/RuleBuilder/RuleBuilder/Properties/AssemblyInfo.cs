using System.Reflection;
using System.Runtime.InteropServices;

[assembly: AssemblyTitle("NRules.Samples.RuleBuilder")]
[assembly: AssemblyDescription("")]
[assembly: ComVisible(false)]
