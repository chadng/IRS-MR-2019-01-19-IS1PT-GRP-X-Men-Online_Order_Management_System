using System.Reflection;
using System.Runtime.InteropServices;

[assembly: AssemblyTitle("NRules.Samples.ClaimsExpert.Service")]
[assembly: AssemblyDescription("")]
[assembly: ComVisible(false)]
