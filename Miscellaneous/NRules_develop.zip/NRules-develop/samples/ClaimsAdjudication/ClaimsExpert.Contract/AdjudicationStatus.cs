﻿namespace NRules.Samples.ClaimsExpert.Contract
{
    public enum AdjudicationStatus
    {
        Open = 0,
        Approved = 1,
        Denied = 2,
        Review = 3,
    }
}