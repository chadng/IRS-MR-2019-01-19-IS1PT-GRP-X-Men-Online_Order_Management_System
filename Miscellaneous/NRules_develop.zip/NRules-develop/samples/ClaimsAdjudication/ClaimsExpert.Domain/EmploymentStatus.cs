﻿namespace NRules.Samples.ClaimsExpert.Domain
{
    public enum EmploymentStatus
    {
        Unspecified = 0,
        Employed = 1,
        FullTimeStudent = 2,
        PartTimeStudent = 3,
        Unemployed = 4,
        Other = 5,
    }
}