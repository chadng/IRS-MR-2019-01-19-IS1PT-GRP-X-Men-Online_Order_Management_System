﻿namespace NRules.Samples.ClaimsExpert.Domain
{
    public enum ClaimStatus
    {
        Open = 0,
        Approved = 1,
        Denied = 2,
        Review = 3,
    }
}