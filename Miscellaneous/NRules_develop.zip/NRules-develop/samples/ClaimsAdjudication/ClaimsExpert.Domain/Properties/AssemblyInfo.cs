using System.Reflection;
using System.Runtime.InteropServices;

[assembly: AssemblyTitle("NRules.Samples.ClaimsExpert.Domain")]
[assembly: AssemblyDescription("")]
[assembly: ComVisible(false)]
