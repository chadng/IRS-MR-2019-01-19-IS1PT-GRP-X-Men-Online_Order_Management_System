namespace NRules.Samples.ClaimsExpert.Domain
{
    public enum ClaimType
    {
        Unspecified = 0,
        Professional = 1,
        Institutional = 2,
    }
}