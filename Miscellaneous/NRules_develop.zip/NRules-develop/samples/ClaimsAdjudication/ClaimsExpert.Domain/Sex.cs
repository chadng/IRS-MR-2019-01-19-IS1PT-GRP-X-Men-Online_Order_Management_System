﻿namespace NRules.Samples.ClaimsExpert.Domain
{
    public enum Sex
    {
        Unspecified = 0,
        Male = 1,
        Female = 2,
    }
}