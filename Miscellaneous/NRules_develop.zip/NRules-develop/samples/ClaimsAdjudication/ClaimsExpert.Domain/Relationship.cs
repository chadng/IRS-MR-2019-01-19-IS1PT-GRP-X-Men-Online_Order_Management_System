﻿namespace NRules.Samples.ClaimsExpert.Domain
{
    public enum Relationship
    {
        Unspecified = 0,
        Self = 1,
        Spouse = 2,
        Child = 3,
        Other = 4,
    }
}