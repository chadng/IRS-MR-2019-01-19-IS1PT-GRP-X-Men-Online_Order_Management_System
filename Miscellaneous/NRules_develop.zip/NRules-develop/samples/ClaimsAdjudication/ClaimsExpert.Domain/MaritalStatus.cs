﻿namespace NRules.Samples.ClaimsExpert.Domain
{
    public enum MaritalStatus
    {
        Unspecified = 0,
        Single = 1,
        Married = 2,
        Other = 3,
    }
}