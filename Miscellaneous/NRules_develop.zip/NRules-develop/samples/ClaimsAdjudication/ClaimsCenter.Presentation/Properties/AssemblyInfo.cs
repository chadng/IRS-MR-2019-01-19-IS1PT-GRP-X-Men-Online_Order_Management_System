using System.Reflection;
using System.Runtime.InteropServices;

[assembly: AssemblyTitle("NRules.Samples.ClaimsCenter.Presentation")]
[assembly: AssemblyDescription("")]
[assembly: ComVisible(false)]
