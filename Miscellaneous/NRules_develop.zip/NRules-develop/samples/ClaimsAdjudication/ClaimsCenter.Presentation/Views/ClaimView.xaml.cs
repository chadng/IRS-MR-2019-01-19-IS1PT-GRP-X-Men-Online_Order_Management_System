﻿using NRules.Samples.ClaimsCenter.Applications.Views;

namespace NRules.Samples.ClaimsCenter.Presentation.Views
{
    public partial class ClaimView : IClaimView
    {
        public ClaimView()
        {
            InitializeComponent();
        }
    }
}
