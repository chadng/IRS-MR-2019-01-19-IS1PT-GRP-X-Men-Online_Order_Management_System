﻿using System.Waf.Applications;

namespace NRules.Samples.ClaimsCenter.Applications.Views
{
    public interface IClaimListView : IView
    {
    }
}
