using System.Reflection;
using System.Runtime.InteropServices;

[assembly: AssemblyTitle("NRules.Samples.ClaimsCenter.Applications")]
[assembly: AssemblyDescription("")]
[assembly: ComVisible(false)]
