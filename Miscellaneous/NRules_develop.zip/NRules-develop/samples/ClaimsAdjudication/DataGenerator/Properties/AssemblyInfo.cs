using System.Reflection;
using System.Runtime.InteropServices;

[assembly: AssemblyTitle("NRules.Samples.ClaimsExpert.Database")]
[assembly: AssemblyDescription("")]
[assembly: ComVisible(false)]
