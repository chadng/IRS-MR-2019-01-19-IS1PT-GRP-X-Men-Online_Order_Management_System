using System.Reflection;
using System.Runtime.InteropServices;

[assembly: AssemblyTitle("NRules.Samples.ClaimsExpert.Rules")]
[assembly: AssemblyDescription("")]
[assembly: ComVisible(false)]
