﻿using NRules.RuleModel;

namespace NRules.IntegrationTests.TestAssets
{
    public static class ContextExtensions
    {
        public static void NoOp(this IContext context)
        {
        }
    }
}
