﻿namespace NRules.Rete
{
    internal class Quantifier
    {
        public int Value { get; set; }
    }
}