using System.Reflection;
using System.Runtime.InteropServices;

[assembly: AssemblyTitle("NRules.Integration.Autofac")]
[assembly: AssemblyDescription("Autofac integration for NRules")]
[assembly: ComVisible(false)]
