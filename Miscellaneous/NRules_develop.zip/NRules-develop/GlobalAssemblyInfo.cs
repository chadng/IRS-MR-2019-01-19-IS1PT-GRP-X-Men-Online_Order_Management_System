using System.Reflection;

[assembly: AssemblyCompany("NRules")]
[assembly: AssemblyCopyright("Copyright 2012-2019 Sergiy Nikolayev. All rights reserved.")]
[assembly: AssemblyVersion("1.0.0.0")]
[assembly: AssemblyFileVersion("1.0.0.0")]
[assembly: AssemblyInformationalVersionAttribute("1.0.0.0")]
